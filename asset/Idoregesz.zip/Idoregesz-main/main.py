import jatek

jatek.jatekmenet()