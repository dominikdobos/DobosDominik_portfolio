# PizzAppFork
## GUI: CsP
Fork után a programozás közös feladat
Dobos Dominik
