import tetelsor
import vonalak


tetelsor.tetel_szam
vonalak.nyugta()
tetelsor.tetelsorok()
tetelsor.osszesit()
tetelsor.fizetendo()
vonalak.alairas()
vonalak.ceg()