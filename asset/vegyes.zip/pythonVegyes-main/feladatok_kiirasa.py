import feladatok


def kiir():
    feladatok.feladat_1()
    print()
    feladatok.feladat_2()
    print()
    feladatok.feladat_3()
    print()
    feladatok.feladat_4()
    print()
    feladatok.feladat_5()
    print()
    feladatok.feladat_6()
    print()
    feladatok.feladat_7()
    print()
    feladatok.feladat_8()
    print()
    feladatok.feladat_9()
