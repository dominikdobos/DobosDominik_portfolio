import feladatok
import feladatok_kiirasa

feladatok_kiirasa.kiir()
