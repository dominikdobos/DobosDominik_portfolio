# Cicás OnePage

Grid alapok és alapformázások gyakorlására

## Az oldal drótváza és mintái

### 1. blokk:

![1. mintakép](mintak/1.PNG "1. mintakép")
![1. drótváz](mintak/1d.PNG "1. drótváz")

### 2. blokk:

![2. mintakép](mintak/2.PNG "2. mintakép")
![2. drótváz](mintak/2d.PNG "2. drótváz")

### 3. blokk:

![3. mintakép](mintak/3.PNG "3. mintakép")
![3. drótváz](mintak/3d.PNG "3. drótváz")

### 4. blokk:

![4. mintakép](mintak/4.PNG "4. mintakép")
A drótvázat rajzold meg önállóan!

### 5. blokk:

![5. mintakép](mintak/5.PNG "5. mintakép")
A drótvázat rajzold meg önállóan!

### 6. blokk:

![6. mintakép](mintak/6.PNG "6. mintakép")
A drótvázat rajzold meg önállóan!
